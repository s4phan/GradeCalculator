package sheehan.phan.gradecalculatorf;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;

public class GradeCalculator extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_grade_calculator);
        final EditText currentGradeValue = findViewById(R.id.currentGradeValue);
        final EditText testMarkValue = findViewById(R.id.testMarkValue);
        final EditText testWeightValue =  findViewById(R.id.testWeightValue);
        final Button newGrade =  findViewById(R.id.newGrade);
        final TextView GradeLabel =  findViewById(R.id.GradeLabel);
        final TextView currentGrade = findViewById(R.id.currentGrade);
        final TextView testMark = findViewById(R.id.testMark);
        final TextView testWeight = findViewById(R.id.testWeight);
        final TextView xnahps = findViewById(R.id.xnahps);
        final ImageView henryboys = findViewById(R.id.henryboys);



        newGrade.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Double currentGrade1 = Double.parseDouble(currentGradeValue.getText().toString());
                Double testMark1 = Double.parseDouble(testMarkValue.getText().toString());
                Double testWeight1 = Double.parseDouble(testWeightValue.getText().toString());

                Double gradeWeightConverted = testWeight1 / 100;
                Double a = 1 - gradeWeightConverted;

                Double newGrades = (currentGrade1 * a) + (testMark1 * gradeWeightConverted);
                Double newGradeConverted = (newGrades * 100.0) / 100;
                final String newGradeConverteds = Double.toString(newGradeConverted);

                GradeLabel.setText(newGradeConverteds + "% - nice going boy. lol");
            }

        });


    }
}
